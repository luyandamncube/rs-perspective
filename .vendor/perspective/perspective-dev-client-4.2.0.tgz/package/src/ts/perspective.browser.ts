// ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
// ┃ ██████ ██████ ██████       █      █      █      █      █ █▄  ▀███ █       ┃
// ┃ ▄▄▄▄▄█ █▄▄▄▄▄ ▄▄▄▄▄█  ▀▀▀▀▀█▀▀▀▀▀ █ ▀▀▀▀▀█ ████████▌▐███ ███▄  ▀█ █ ▀▀▀▀▀ ┃
// ┃ █▀▀▀▀▀ █▀▀▀▀▀ █▀██▀▀ ▄▄▄▄▄ █ ▄▄▄▄▄█ ▄▄▄▄▄█ ████████▌▐███ █████▄   █ ▄▄▄▄▄ ┃
// ┃ █      ██████ █  ▀█▄       █ ██████      █      ███▌▐███ ███████▄ █       ┃
// ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
// ┃ Copyright (c) 2017, the Perspective Authors.                              ┃
// ┃ ╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌ ┃
// ┃ This file is part of the Perspective library, distributed under the terms ┃
// ┃ of the [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0). ┃
// ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

export type * from "../../dist/wasm/perspective-js.d.ts";
import type * as psp from "../../dist/wasm/perspective-js.d.ts";
export type * from "./virtual_server.ts";
import * as psp_virtual from "./virtual_server.ts";
import * as wasm_module from "../../dist/wasm/perspective-js.js";
import * as api from "./wasm/browser.ts";
import { load_wasm_stage_0 } from "./wasm/decompress.ts";

export {
    GenericSQLVirtualServerModel,
    VirtualDataSlice,
    VirtualServer,
} from "../../dist/wasm/perspective-js.js";

import {
    GenericSQLVirtualServerModel,
    VirtualDataSlice,
    VirtualServer,
} from "../../dist/wasm/perspective-js.js";

let GLOBAL_SERVER_WASM: Promise<ArrayBuffer | WebAssembly.Module>;

export async function createMessageHandler(
    handler: psp_virtual.VirtualServerHandler,
) {
    return psp_virtual.createMessageHandler(await get_client(), handler);
}

export function init_server(
    wasm:
        | Uint8Array
        | Promise<ArrayBuffer | Response | WebAssembly.Module>
        | ArrayBuffer
        | Response
        | WebAssembly.Module,
    disable_stage_0: boolean = false,
) {
    if (wasm instanceof Uint8Array) {
        GLOBAL_SERVER_WASM = Promise.resolve(wasm.buffer);
    } else if (wasm instanceof Response) {
        GLOBAL_SERVER_WASM = Promise.resolve(wasm);
    } else if (wasm instanceof Promise) {
        GLOBAL_SERVER_WASM = wasm;
    } else {
        GLOBAL_SERVER_WASM = Promise.resolve(wasm);
    }

    if (!disable_stage_0) {
        GLOBAL_SERVER_WASM = GLOBAL_SERVER_WASM.then((x) =>
            load_wasm_stage_0(x).then((x) => x.buffer as ArrayBuffer),
        );
    }
}

let GLOBAL_CLIENT_WASM: Promise<typeof psp>;

async function compilerize(
    wasm: PerspectiveWasm,
    disable_stage_0: boolean = false,
) {
    const wasm_buff = disable_stage_0 ? wasm : await load_wasm_stage_0(wasm);
    await wasm_module.default({ module_or_path: wasm_buff });
    await wasm_module.init();
    return wasm_module;
}

export type PerspectiveWasm =
    | ArrayBuffer
    | Response
    | typeof psp
    | Promise<ArrayBuffer | Response | Object>;

export function init_client(wasm: PerspectiveWasm, disable_stage_0 = false) {
    if (wasm instanceof Uint8Array) {
        GLOBAL_CLIENT_WASM = compilerize(
            wasm.buffer as ArrayBuffer,
            disable_stage_0,
        );
    } else if (wasm instanceof ArrayBuffer) {
        GLOBAL_CLIENT_WASM = compilerize(wasm, disable_stage_0);
    } else if (wasm instanceof Response) {
        GLOBAL_CLIENT_WASM = compilerize(wasm, disable_stage_0);
    } else if (wasm instanceof Promise) {
        GLOBAL_CLIENT_WASM = compilerize(wasm, disable_stage_0);
    } else if (wasm instanceof Object) {
        GLOBAL_CLIENT_WASM = Promise.resolve(wasm as typeof psp);
    }
}

function get_client() {
    const viewer_class: any = customElements.get("perspective-viewer");
    if (viewer_class) {
        GLOBAL_CLIENT_WASM = Promise.resolve(viewer_class.__wasm_module__);
    } else if (GLOBAL_CLIENT_WASM === undefined) {
        throw new Error("Missing perspective-client.wasm");
    }

    return GLOBAL_CLIENT_WASM;
}

function get_server() {
    if (GLOBAL_SERVER_WASM === undefined) {
        throw new Error("Missing perspective-server.wasm");
    }

    return GLOBAL_SERVER_WASM.then((x) =>
        x instanceof WebAssembly.Module ? x : x.slice(0),
    );
}

let GLOBAL_WORKER: undefined | (() => Promise<Worker>) = undefined;

// Inline the worker for now. This code will eventually allow outlining this resource
// @ts-ignore
import perspective_wasm_worker from "../../src/ts/perspective-server.worker.js";

function get_worker(): Promise<Worker> {
    if (GLOBAL_WORKER === undefined) {
        return perspective_wasm_worker();
    }

    return GLOBAL_WORKER();
}

export async function websocket(url: string | URL) {
    return await api.websocket(get_client(), url);
}

export async function worker(
    worker?: Promise<SharedWorker | ServiceWorker | Worker | MessagePort>,
) {
    if (typeof worker === "undefined") {
        worker = get_worker();
    }

    return await api.worker(get_client(), get_server(), worker);
}

export default {
    websocket,
    worker,
    init_client,
    init_server,
    createMessageHandler,
    GenericSQLVirtualServerModel,
    VirtualDataSlice,
    VirtualServer,
};
